# markdown-editor

Simple Markdown-HTML Live Preview Editor, built with pure JavaScript; [FileSaver.js](https://github.com/eligrey/FileSaver.js/), [Split.js](https://github.com/nathancahill/Split.js) and [Remarkable.js](https://github.com/jonschlinkert/remarkable).

**URL: http://heiswayi.github.io/markdown-editor**
